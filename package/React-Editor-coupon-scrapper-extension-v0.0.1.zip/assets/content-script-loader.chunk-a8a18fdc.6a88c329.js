(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-a8a18fdc.js")
    );
  })().catch(console.error);

})();
